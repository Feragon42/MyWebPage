$(function(){
  $("#typeProx").typed({
    strings: ["PRÓXIMAMENTE"],
    typeSpeed: 0,
    showCursor: false
  });
  
  $("#typeCons").typed({
    strings: ["PÁGINA EN CONSTRUCCIÓN"],
    typeSpeed: 0,
    showCursor: false
  });
});